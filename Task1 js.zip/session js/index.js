

var proContainer = []
if(JSON.parse(localStorage.getItem("Products"))!= null){
    proContainer = JSON.parse(localStorage.getItem("Products"));
    dispro();
}
 
 
 
var proName =  document.getElementById("proName");
var proPrice =  document.getElementById("proPrice");
var proCategory =  document.getElementById("proCategory");
var proDesc =  document.getElementById("proDesc");
var proSearch =  document.getElementById("proSearch");
var btn =  document.getElementById("btn");
console.log(btn);
var proContainer = []
 
btn.onclick = function(){
 
    var pro= {
        name:proName.value,
        price:proPrice.value,
        category:proCategory.value,
        desc:proDesc.value,
    }

   proContainer.push(pro);
    dispro();
    localStorage.setItem("Products",JSON.stringify(proContainer));
   console.log(proContainer);
}

function dispro(){
    var Allpro = ``
    for (let i=0  ; i< proContainer.length ; i++ ){
        Allpro += `
        <tr>
        <td>${i+1}</td>
         <td>${proContainer[i].name}</td>
          <td>${proContainer[i].price}</td>
           <td>${proContainer[i].category}</td>
            <td>${proContainer[i].desc}</td>
             <td><button class="btn delete" onclick=" del(${i})">Delete</button> <button class ="btn update" onclick=" Update(${i})" >Update</button></td>
        </tr>
        `
    }
    console.log(Allpro)
    document.getElementById("tbody").innerHTML= Allpro ;

}
function del(index){
    proContainer.splice(index,1);
    localStorage.setItem("Products",JSON.stringify(proContainer));
    dispro();
 
}
proSearch.onkeyup = function() {
       search(proSearch.value)
}

function search(Pname){
     var Allpro = ``
    for (let i=0  ; i< proContainer.length ; i++ ){
        if(proContainer[i].name.toLowerCase().includes(Pname.toLowerCase())){
             Allpro += `
        <tr>
        <td>${i+1}</td>
         <td>${proContainer[i].name}</td>
          <td>${proContainer[i].price}</td>
           <td>${proContainer[i].category}</td>
            <td>${proContainer[i].desc}</td>
             <td><button class="btn delete" onclick=" del(${i})">Delete</button> <button class ="btn update" onclick=" Update(${i})">Update</button></td>
        </tr>
        `
        }
       }
       document.getElementById("tbody").innerHTML= Allpro ;
}

var updateIndex = -1; 
function Update(index){ 
    proName.value = proContainer[index].name;
    proPrice.value = proContainer[index].price;
    proCategory.value = proContainer[index].category;
    proDesc.value = proContainer[index].desc;

    updateIndex = index; 
    btn.innerHTML = "Update"; 
}

btn.onclick = function(){
    if(updateIndex === -1){
    
        var pro= {
            name:proName.value,
            price:proPrice.value,
            category:proCategory.value,
            desc:proDesc.value,
        }
        proContainer.push(pro);
    } else{
        proContainer[updateIndex].name = proName.value;
        proContainer[updateIndex].price = proPrice.value;
        proContainer[updateIndex].category = proCategory.value;
        proContainer[updateIndex].desc = proDesc.value;
        updateIndex = -1;
        btn.innerHTML = "Add Product" ;
    }

    localStorage.setItem("Products",JSON.stringify(proContainer));
    dispro();
}



    
